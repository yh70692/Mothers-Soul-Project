<?php

$db = 'mysql:host=localhost;dbname=ms_db';
$db_name = 'root';
$db_password = '';

$conn = new PDO($db, $db_name, $db_password);

?>