<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>contact us</h3>
         <a href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoyL9Frn6VLTgjkfge6OG_MLqVQPxQZarI8g&usqp=CAU"><i class="fas fa-message"></i>Message</a>
         <a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"><i class="fas fa-fax"></i> +273 765 2533</a>
         <a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"><i class="fas fa-envelope"></i> mothersoul@mail.com</a>
      </div>

      <div class="box">
         <h3>Checkout Our Socials</h3>
         <a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"><i class="fab fa-instagram"></i>instagram</a>
         <a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"><i class="fab fa-facebook-f"></i>facebook</a>
         <a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"><i class="fab fa-linkedin"></i>linkedin</a>
      </div>

   </section>

   <div class="credit">copyright @ 2023 by <span><a href="https://www.youtube.com/watch?v=xvFZjo5PgG0/"> Mothers Soul .LTE</a></span></div>

</footer>